package com.itachi1706.busarrivalsg.AsyncTasks.Services;

import android.content.Context;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;

import com.getpebble.android.kit.PebbleKit;
import com.getpebble.android.kit.util.PebbleDictionary;
import com.google.gson.Gson;
import com.itachi1706.appupdater.Util.URLHelper;
import com.itachi1706.busarrivalsg.gsonObjects.sgLTA.BusArrivalArrayObject;
import com.itachi1706.busarrivalsg.gsonObjects.sgLTA.BusArrivalMain;
import com.itachi1706.busarrivalsg.objects.BusServices;
import com.itachi1706.busarrivalsg.objects.BusStatus;
import com.itachi1706.busarrivalsg.util.PebbleEnum;
import com.itachi1706.busarrivalsg.util.StaticVariables;

import java.io.IOException;
import java.net.SocketTimeoutException;

/**
 * Created by Kenneth on 20/6/2015
 * for SingBuses in package com.itachi1706.busarrivalsg.AsyncTasks
 */
public class GetFirstFavouriteData extends AsyncTask<BusServices, Void, String> {

    private Exception exception = null;
    private Context context;

    private BusServices busObj;

    public GetFirstFavouriteData(Context context){
        this.context = context;
    }

    @Override
    protected String doInBackground(BusServices... busObject) {
        this.busObj = busObject[0];
        String url = "https://api.itachi1706.com/api/busarrival.php?BusStopCode=" + this.busObj.getStopID() + "&ServiceNo=" + this.busObj.getServiceNo() + "&api=2";
        String tmp = "";

        Log.d("GET-FIRST-BUS-SERVICE", url);
        try {
            URLHelper urlHelper = new URLHelper(url);
            tmp = urlHelper.executeString();
        } catch (IOException e) {
            exception = e;
        }
        return tmp;
    }

    protected void onPostExecute(String json) {
        if (exception != null) {
            if (exception instanceof SocketTimeoutException) {
                Log.e("PebbleComm First Fav", "Request Timed Out, Retrying");
                new GetFirstFavouriteData(context).executeOnExecutor(THREAD_POOL_EXECUTOR, busObj);
            } else {
                Log.e("PebbleComm First Fav", exception.getMessage());
            }
        } else {
            //Go parse it
            Gson gson = new Gson();
            if (!StaticVariables.INSTANCE.checkIfYouGotJsonString(json)) {
                //Invalid string, retrying
                Log.e("PebbleComm First Fav", "Invalid JSON String, Retrying");
                new GetFirstFavouriteData(context).executeOnExecutor(THREAD_POOL_EXECUTOR, busObj);
                return;
            }

            BusArrivalMain mainArr = gson.fromJson(json, BusArrivalMain.class);
            BusArrivalArrayObject[] array = mainArr.getServices();

            if (array.length == 0 || array.length > 1) {
                Log.e("PebbleComm First Fav", "A weird error occured. It seems that the array received had a size of " + array.length);
                if (array.length == 0) {
                    Log.e("PebbleComm First Fav", "Retrying...");
                    new GetFirstFavouriteData(context).executeOnExecutor(THREAD_POOL_EXECUTOR, busObj);
                    return;
                } else {
                    Log.e("PebbleComm First Fav", "Gonna use first data");
                }
            }
            //Assuming One
            Log.i("PebbleComm First Fav", "Processing " + busObj.getServiceNo() + " at code " + busObj.getStopID());
            BusArrivalArrayObject item = array[0];

            BusStatus nextBus = new BusStatus();
            nextBus.setEstimatedArrival(item.getNextBus().getEstimatedArrival());
            nextBus.setIsWheelChairAccessible(item.getNextBus().getFeature());
            nextBus.setLoad(item.getNextBus().getLoad());

            BusStatus subsequentBus = new BusStatus();
            subsequentBus.setEstimatedArrival(item.getNextBus2().getEstimatedArrival());
            subsequentBus.setIsWheelChairAccessible(item.getNextBus2().getFeature());
            subsequentBus.setLoad(item.getNextBus2().getLoad());

            busObj.setCurrentBus(nextBus);
            busObj.setNextBus(subsequentBus);
            busObj.setTime(System.currentTimeMillis());
            busObj.setObtainedNextData(true);

            // Get servertime
            boolean serverTime = StaticVariables.INSTANCE.useServerTime(PreferenceManager.getDefaultSharedPreferences(context));

            //Go through arrayList and update the current one
            for (int i = 0; i < StaticVariables.INSTANCE.getFavouritesList().size(); i++) {
                BusServices ob = StaticVariables.INSTANCE.getFavouritesList().get(i);
                if (ob.getServiceNo().equals(busObj.getServiceNo()) && ob.getStopID().equals(busObj.getStopID())) {
                    //Update
                    StaticVariables.INSTANCE.getFavouritesList().set(i, busObj);
                    break;
                }
            }

            //Get First Object and parse it
            BusServices ob = StaticVariables.INSTANCE.getFavouritesList().get(0);
            String currentEst;
            String nextEst;
            if (ob.getNextBus().getEstimatedArrival() == null) {
                nextEst = "-";
            } else {
                long estNxt = StaticVariables.INSTANCE.parseEstimateArrival(ob.getNextBus().getEstimatedArrival(), serverTime, mainArr.getCurrentTime());
                if (estNxt <= 0)
                    nextEst = "Arr";
                else if (estNxt == 1)
                    nextEst = estNxt + " min";
                else
                    nextEst = estNxt + " mins";
            }
            if (ob.getCurrentBus().getEstimatedArrival() == null) {
                currentEst = "-";
            } else {
                long estCur = StaticVariables.INSTANCE.parseEstimateArrival(ob.getCurrentBus().getEstimatedArrival(), serverTime, mainArr.getCurrentTime());
                if (estCur <= 0)
                    currentEst = "Arr";
                else if (estCur == 1)
                    currentEst = estCur + " min";
                else
                    currentEst = estCur + " mins";
            }

            //Push first to pebble
            PebbleDictionary dict1 = new PebbleDictionary();
            PebbleDictionary dict2 = new PebbleDictionary();
            PebbleDictionary dict3 = new PebbleDictionary();
            dict1.addInt16(PebbleEnum.MESSAGE_DATA_EVENT, (short) 1);
            dict2.addInt16(PebbleEnum.MESSAGE_DATA_EVENT, (short) 2);
            dict3.addInt16(PebbleEnum.MESSAGE_DATA_EVENT, (short) 3);
            if (ob.getStopName() == null)
                dict1.addString(PebbleEnum.MESSAGE_ROAD_NAME, "Unknown Stop");
            else
                dict1.addString(PebbleEnum.MESSAGE_ROAD_NAME, ob.getStopName().trim());
            dict2.addString(PebbleEnum.MESSAGE_BUS_SERVICE, ob.getServiceNo().trim());
            dict2.addString(PebbleEnum.MESSAGE_ROAD_CODE, ob.getStopID().trim());
            dict2.addInt16(PebbleEnum.MESSAGE_MAX_FAV, (short) StaticVariables.INSTANCE.getFavouritesList().size());
            dict2.addInt16(PebbleEnum.MESSAGE_CURRENT_FAV, (short) 1);
            dict3.addString(PebbleEnum.ESTIMATE_ARR_CURRENT_DATA, currentEst.trim());
            dict3.addInt16(PebbleEnum.ESTIMATE_LOAD_CURRENT_DATA, (short) ob.getCurrentBus().getLoad());
            dict3.addString(PebbleEnum.ESTIMATE_ARR_NEXT_DATA, nextEst.trim());
            dict3.addInt16(PebbleEnum.ESTIMATE_LOAD_NEXT_DATA, (short) ob.getNextBus().getLoad());

            //Send WAB status
            dict2.addInt8(PebbleEnum.MESSAGE_WAB_CURRENT, StaticVariables.INSTANCE.parseWABStatusToPebble(ob.getCurrentBus().isWheelChairAccessible()));
            dict2.addInt8(PebbleEnum.MESSAGE_WAB_NEXT, StaticVariables.INSTANCE.parseWABStatusToPebble(ob.getNextBus().isWheelChairAccessible()));

            Log.i("PebbleComm First Fav", "Sending to Pebble...");
            PebbleKit.sendDataToPebbleWithTransactionId(context, StaticVariables.INSTANCE.getPEBBLE_APP_UUID(), dict1, 1);
            StaticVariables.INSTANCE.setDict1(dict1);
            StaticVariables.INSTANCE.setDict2(dict2);
            StaticVariables.INSTANCE.setDict3(dict3);
        }
    }
}
