void show_bus_layout(void);
void hide_bus_layout(void);
